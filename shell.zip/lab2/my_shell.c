#include  <stdio.h>
#include  <sys/types.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>

#define MAX_INPUT_SIZE 1024
#define MAX_TOKEN_SIZE 64
#define MAX_NUM_TOKENS 64

// TODO : Make bg_group and pg_group as pid of first process
// TODO : code system to reap terminated background processes
/* Splits the string by space and returns the array of tokens
*
*/
char **tokenize(char *line)
{
  char **tokens = (char **)malloc(MAX_NUM_TOKENS * sizeof(char *));
  char *token = (char *)malloc(MAX_TOKEN_SIZE * sizeof(char));
  int i, tokenIndex = 0, tokenNo = 0;

  for(i =0; i < strlen(line); i++){

    char readChar = line[i];

    if (readChar == ' ' || readChar == '\n' || readChar == '\t'){
      token[tokenIndex] = '\0';
      if (tokenIndex != 0){
	tokens[tokenNo] = (char*)malloc(MAX_TOKEN_SIZE*sizeof(char));
	strcpy(tokens[tokenNo++], token);
	tokenIndex = 0; 
      }
    } else {
      token[tokenIndex++] = readChar;
    }
  }
 
  free(token);
  tokens[tokenNo] = NULL ;
  return tokens;
}


int main(int argc, char* argv[]) {
	char  line[MAX_INPUT_SIZE];
	char  **tokens;  
	int i;


	while(1) {	
		/* BEGIN: TAKING INPUT */
		bzero(line, sizeof(line));
		printf("$ ");
		scanf("%[^\n]", line);
		getchar();

		// printf("Command entered: %s (remove this debug output later)\n", line);
		// /* END: TAKING INPUT */

		line[strlen(line)] = '\n'; //terminate with new line
		tokens = tokenize(line);
		int bg_group = 5;
		int fg_group = 6;

		bool is_background = 0;

		for(int i=0; tokens[i]!=NULL; i++){
			if(!strcmp (tokens[i], "&")){
				is_background = 1;
				tokens[i] = NULL;
			}
		}

       //do whatever you want with the commands, here we just print them

		// for(i=0;tokens[i]!=NULL;i++){
		// 	printf("found token %s (remove this debug output later)\n", tokens[i]);
		// }
       	if(!strcmp (tokens[0], "exit")){
			printf("gonna die\n");
			kill(-bg_group, SIGKILL);
			
			for(i=0;tokens[i]!=NULL;i++){
				free(tokens[i]);
			}
			free(tokens);
			
			exit(EXIT_SUCCESS);

		}else{
		if(! strcmp(tokens[0],"cd")){
			chdir(tokens[1]);
			goto manager;
		}
		else{
			int r = fork();
			if(r<0){
				printf("Failed\n");
			}
			else if(r==0){
				if(is_background == 1){
					setpgid(0, bg_group);
				}
				else{
					setpgid(0, fg_group);
				}
				execvp(tokens[0], tokens);
				exit(EXIT_SUCCESS);
			}
			else{
				
				if(!is_background == 1){
				
					int wc = wait(NULL);
				}
			}
		}
		// Freeing the allocated memory	
		manager:
		for(i=0;tokens[i]!=NULL;i++){
			free(tokens[i]);
		}
		free(tokens);

	}
	}
	return 0;
}
