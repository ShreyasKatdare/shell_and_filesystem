#include  <stdio.h>
#include  <sys/types.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>
#define MAX_INPUT_SIZE 1024
#define MAX_TOKEN_SIZE 64
#define MAX_NUM_TOKENS 64

/* Splits the string by space and returns the array of tokens
*
*/
char **tokenize(char *line)
{
  char **tokens = (char **)malloc(MAX_NUM_TOKENS * sizeof(char *));
  char *token = (char *)malloc(MAX_TOKEN_SIZE * sizeof(char));
  int i, tokenIndex = 0, tokenNo = 0;

  for(i =0; i < strlen(line); i++){

    char readChar = line[i];

    if (readChar == ' ' || readChar == '\n' || readChar == '\t'){
      token[tokenIndex] = '\0';
      if (tokenIndex != 0){
	tokens[tokenNo] = (char*)malloc(MAX_TOKEN_SIZE*sizeof(char));
	strcpy(tokens[tokenNo++], token);
	tokenIndex = 0; 
      }
    } else {
      token[tokenIndex++] = readChar;
    }
  }
 
  free(token);
  tokens[tokenNo] = NULL ;
  return tokens;
}

void manager(char** tokens){
    for(int i =0;tokens[i]!=NULL;i++){
        free(tokens[i]);
    }
    free(tokens);
}
int bgnum = 0;
int fgnum = 0;

int main(int argc, char* argv[]) {
	char  line[MAX_INPUT_SIZE];            
	char  **tokens;              
	int i;


	while(1) {			
		/* BEGIN: TAKING INPUT */
		bzero(line, sizeof(line));
		printf("$ ");
		scanf("%[^\n]", line);
		getchar();

		

		line[strlen(line)] = '\n'; //terminate with new line
		tokens = tokenize(line);
   
       //do whatever you want with the commands, here we just print them

        // First see if any background process has terminated
        int check;
        if(check = waitpid(-1, NULL, WNOHANG)>0){
            printf("Some Background process terminated and reaped");
        }

        // handle exit
        if(!strcmp(tokens[0],"exit")){
            manager(tokens);
            kill(-getpid(), SIGTERM);
            exit(0);
        }
		
        // find whether background or not
        int bg = 0;
        for(int i =0;tokens[i]!=NULL;i++){
            if(!strcmp(tokens[i], "&") && tokens[i+1]==NULL){
                tokens[i] = NULL;
                bg =1;
            }
            
        }


        // handle cd
        if(!strcmp(tokens[0],"cd")){
            if(chdir(tokens[1])){
                printf("galat folder name bro !\n");
                manager(tokens);
            }
            else manager(tokens);
        }else{
            int r = fork();
            if(r==0){
                if(execvp(tokens[0], tokens) == -1){
                    printf("galat command bro\n");
                    manager(tokens);
                    continue;
                }
            }else {
                if(bg != 1){
                    waitpid(r, NULL, 0);
                }
            }

        }



       
		// Freeing the allocated memory	
		manager(tokens);
	}
	return 0;
}
