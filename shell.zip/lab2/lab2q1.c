#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char* argv[]){
    printf("Hello (pid:%d)\n", (int) getpid());
    int f = fork();
    if(f==0){
        printf("I'm child %d\n",getpid());
        exit(1);
    }
    else if(f>0){
        int wc=wait(NULL);
        printf("I'm parent (pid:%d) of child %d\n", (int) getpid(),f);
        
    } 
    else{
        printf("failed\n");
    }
    return 0;
}